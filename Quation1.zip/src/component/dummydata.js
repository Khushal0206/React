export default[
    {name:"khushal" ,roll_no:253261},
    {name:"amit" ,roll_no:253267},
    {name:"naveen" ,roll_no:253266},
    {name:"vivek" ,roll_no:253265},
    {name:"abhishek" ,roll_no:253264},
    {name:"prachi" ,roll_no:253263}

]