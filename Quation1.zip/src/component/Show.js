export default function Show(props){
    return<>
        <h1>Your Name is {props.sand}</h1>
    </>
}