import axios from "axios" 
export default function Call_API(){
     const get_Url=()=>{
        axios.get("https://cb-ecommerce.onrender.com/api/category/list").then(res=>
        console.log(res.data)
        ).catch(err=>
            console.log("error is occured"))
        ;

    }
     get_Url()

    return<>
        <h1>Call_API</h1>


    </>
}